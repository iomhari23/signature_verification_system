"""
SignVerify API — with MySQL Logging
=====================================
Run  : uvicorn api:app --host 0.0.0.0 --port 8000
Model: place signature_model.pth in same folder

Every verification is saved to MySQL → verification_log table.
"""

import io
import os
import time
import uuid
import logging
from datetime import datetime

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import transforms, models
from torchvision.models import EfficientNet_B0_Weights
from PIL import Image, ImageOps

from fastapi import FastAPI, File, UploadFile, Query
from fastapi.middleware.cors import CORSMiddleware

import mysql.connector
from dotenv import load_dotenv

load_dotenv()

# ── LOGGING ───────────────────────────────────
logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s")
log = logging.getLogger("signverify")

# ── CONFIG ────────────────────────────────────
MODEL_PATH = os.getenv("MODEL_PATH", "signature_model.pth")
DEVICE     = torch.device("cuda" if torch.cuda.is_available() else "cpu")
IMG_SIZE   = 224

DB_CONFIG = {
    "host":     os.getenv("DB_HOST",     "localhost"),
    "port":     int(os.getenv("DB_PORT", "3306")),
    "user":     os.getenv("DB_USER",     "root"),
    "password": os.getenv("DB_PASSWORD", ""),
    "database": os.getenv("DB_NAME",     "signverify"),
}


# ── DATABASE ──────────────────────────────────
def get_db():
    return mysql.connector.connect(**DB_CONFIG)


def init_db():
    """Create table if it doesn't exist."""
    try:
        conn = get_db()
        cur  = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS verification_log (
                id              VARCHAR(36)  PRIMARY KEY,
                checked_at      DATETIME     NOT NULL,
                ref_filename    VARCHAR(255),
                qry_filename    VARCHAR(255),
                verdict         VARCHAR(10)  NOT NULL,
                distance        FLOAT        NOT NULL,
                threshold       FLOAT        NOT NULL,
                similarity_pct  FLOAT,
                confidence      VARCHAR(20),
                processing_ms   INT
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """)
        conn.commit()
        cur.close()
        conn.close()
        log.info("MySQL table ready.")
    except Exception as e:
        log.error(f"DB init failed: {e}")


def save_to_db(entry: dict):
    """Save one verification result to MySQL."""
    try:
        conn = get_db()
        cur  = conn.cursor()
        cur.execute("""
            INSERT INTO verification_log
            (id, checked_at, ref_filename, qry_filename,
             verdict, distance, threshold, similarity_pct,
             confidence, processing_ms)
            VALUES
            (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            entry["id"],
            entry["checked_at"],
            entry["ref_filename"],
            entry["qry_filename"],
            entry["verdict"],
            entry["distance"],
            entry["threshold"],
            entry["similarity_pct"],
            entry["confidence"],
            entry["processing_ms"],
        ))
        conn.commit()
        cur.close()
        conn.close()
    except Exception as e:
        log.error(f"DB save failed: {e}")


# ── MODEL ─────────────────────────────────────
class SiameseNet(nn.Module):
    def __init__(self, embedding_dim=512, dropout=0.4):
        super().__init__()
        backbone = models.efficientnet_b0(weights=EfficientNet_B0_Weights.DEFAULT)
        for p in backbone.parameters(): p.requires_grad = False
        for p in backbone.features[6].parameters(): p.requires_grad = True
        for p in backbone.features[7].parameters(): p.requires_grad = True
        for p in backbone.features[8].parameters(): p.requires_grad = True
        self.features  = backbone.features
        self.avgpool   = backbone.avgpool
        feat_dim       = backbone.classifier[1].in_features
        self.projector = nn.Sequential(
            nn.Linear(feat_dim, 1024), nn.BatchNorm1d(1024),
            nn.ReLU(inplace=True),    nn.Dropout(dropout),
            nn.Linear(1024, embedding_dim), nn.BatchNorm1d(embedding_dim),
        )

    def encode(self, x):
        x = self.features(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        return F.normalize(self.projector(x).float(), p=2, dim=1)


# ── LOAD MODEL ────────────────────────────────
model     = None
threshold = 0.5

def load():
    global model, threshold
    ckpt      = torch.load(MODEL_PATH, map_location=DEVICE, weights_only=False)
    emb_dim   = ckpt.get("embedding_dim", 512)
    model     = SiameseNet(embedding_dim=emb_dim).to(DEVICE)
    model.load_state_dict(ckpt["model_state"])
    model.eval()
    threshold = ckpt.get("threshold", 0.5)
    log.info(f"Model loaded. threshold={threshold}  device={DEVICE}")


# ── IMAGE PREPROCESSING ───────────────────────
normalize = transforms.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225])
to_tensor = transforms.ToTensor()

def preprocess(raw: bytes) -> torch.Tensor:
    img = Image.open(io.BytesIO(raw))
    img = ImageOps.exif_transpose(img)          # fix phone rotation
    img = img.convert("RGB")

    # Dark background → invert
    gray = np.array(img.convert("L"), dtype=np.float32)
    if gray.mean() < 127:
        img  = ImageOps.invert(img)
        gray = np.array(img.convert("L"), dtype=np.float32)

    # Stretch contrast
    lo, hi = gray.min(), gray.max()
    if hi - lo > 10:
        gray = ((gray - lo) / (hi - lo) * 255).astype(np.float32)

    # Auto-crop to signature bounding box
    mask = gray < 200
    rows = np.any(mask, axis=1)
    cols = np.any(mask, axis=0)
    if rows.any() and cols.any():
        r0, r1 = np.where(rows)[0][[0, -1]]
        c0, c1 = np.where(cols)[0][[0, -1]]
        h, w   = gray.shape
        pad    = int(max((r1-r0), (c1-c0)) * 0.05)
        r0 = max(0, r0-pad); r1 = min(h-1, r1+pad)
        c0 = max(0, c0-pad); c1 = min(w-1, c1+pad)
        img = img.crop((c0, r0, c1+1, r1+1))

    # Aspect-preserving resize with white padding
    img.thumbnail((IMG_SIZE, IMG_SIZE), Image.LANCZOS)
    canvas = Image.new("RGB", (IMG_SIZE, IMG_SIZE), (255, 255, 255))
    canvas.paste(img, ((IMG_SIZE - img.width)//2, (IMG_SIZE - img.height)//2))

    return normalize(to_tensor(canvas)).unsqueeze(0).to(DEVICE)


def embed(tensor):
    with torch.no_grad():
        return model.encode(tensor)


# ── APP ───────────────────────────────────────
app = FastAPI(
    title="SignVerify API",
    description="Send two signature images → get GENUINE or FORGED. Every check is saved to MySQL.",
    version="1.0.0",
)

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.on_event("startup")
def startup():
    init_db()
    if os.path.exists(MODEL_PATH):
        load()
    else:
        log.warning(f"Model not found: {MODEL_PATH}")


# ════════════════════════════════════════════════
#  POST /verify  —  main endpoint
# ════════════════════════════════════════════════
@app.post("/verify")
async def verify(
    reference: UploadFile = File(..., description="Known genuine signature"),
    query:     UploadFile = File(..., description="Signature to verify"),
    threshold_override: float = Query(None, gt=0, le=5.0,
        description="Optional: override model threshold"),
):
    """
    Send two images → get verdict. Each check is saved to MySQL.

    curl example:
        curl -X POST http://YOUR_IP:8000/verify \\
          -F "reference=@sign1.png" \\
          -F "query=@sign2.png"
    """
    if model is None:
        return {"error": "Model not loaded. Place signature_model.pth in server folder."}

    ref_bytes = await reference.read()
    qry_bytes = await query.read()

    t0 = time.time()

    ref_tensor = preprocess(ref_bytes)
    qry_tensor = preprocess(qry_bytes)

    distance = F.pairwise_distance(embed(ref_tensor), embed(qry_tensor)).item()
    thr      = threshold_override if threshold_override else threshold
    verdict  = "FORGED" if distance > thr else "GENUINE"
    sim      = round(max(0.0, 1 - distance / (thr * 2)) * 100, 2)

    if distance < thr * 0.5:    confidence = "Very High"
    elif distance < thr * 0.8:  confidence = "High"
    elif distance < thr:        confidence = "Moderate"
    elif distance < thr * 1.3:  confidence = "Low"
    else:                       confidence = "Very Low"

    elapsed_ms = int((time.time() - t0) * 1000)
    log_id     = str(uuid.uuid4())

    # ── Save to MySQL ──────────────────────────
    save_to_db({
        "id":             log_id,
        "checked_at":     datetime.utcnow(),
        "ref_filename":   reference.filename,
        "qry_filename":   query.filename,
        "verdict":        verdict,
        "distance":       round(distance, 6),
        "threshold":      round(thr, 2),
        "similarity_pct": sim,
        "confidence":     confidence,
        "processing_ms":  elapsed_ms,
    })

    log.info(f"[{log_id[:8]}] {reference.filename} vs {query.filename} → {verdict}  dist={distance:.4f}  saved to DB")

    return {
        "id":             log_id,
        "verdict":        verdict,
        "distance":       round(distance, 4),
        "threshold":      round(thr, 2),
        "similarity_pct": sim,
        "confidence":     confidence,
        "ref_filename":   reference.filename,
        "qry_filename":   query.filename,
        "processing_ms":  elapsed_ms,
    }


# ════════════════════════════════════════════════
#  GET /logs  —  see all saved verifications
# ════════════════════════════════════════════════
@app.get("/logs")
def get_logs(
    limit:   int = Query(50, ge=1, le=500),
    verdict: str = Query(None, description="Filter: GENUINE or FORGED"),
):
    """Fetch past verifications saved in MySQL."""
    try:
        conn = get_db()
        cur  = conn.cursor(dictionary=True)

        if verdict:
            cur.execute("""
                SELECT * FROM verification_log
                WHERE verdict = %s
                ORDER BY checked_at DESC LIMIT %s
            """, (verdict.upper(), limit))
        else:
            cur.execute("""
                SELECT * FROM verification_log
                ORDER BY checked_at DESC LIMIT %s
            """, (limit,))

        rows = cur.fetchall()
        cur.close()
        conn.close()

        for r in rows:
            if isinstance(r.get("checked_at"), datetime):
                r["checked_at"] = r["checked_at"].isoformat()

        return {"count": len(rows), "logs": rows}

    except Exception as e:
        return {"error": str(e)}


# ── HEALTH ────────────────────────────────────
@app.get("/health")
def health():
    db_ok = False
    try:
        conn = get_db(); conn.close(); db_ok = True
    except Exception:
        pass
    return {
        "model_loaded": model is not None,
        "db_connected": db_ok,
        "threshold":    threshold,
        "device":       str(DEVICE),
    }
