"""
camera.py — Camera manager with full edge-case handling.

Handles:
  - Camera not found / wrong index
  - Camera disconnected mid-session
  - Frame read failures (returns None instead of crashing)
  - Resolution / FPS negotiation
  - Auto-reconnect on disconnect
  - Context manager support
"""

import logging
import time
from typing import Optional

import cv2
import numpy as np

from config import CAMERA_INDEX, CAMERA_WIDTH, CAMERA_HEIGHT, CAMERA_FPS

logger = logging.getLogger(__name__)


class CameraError(Exception):
    pass


class Camera:
    """
    Thread-safe camera wrapper with auto-reconnect.
    Use as a context manager:

        with Camera() as cam:
            frame = cam.read()
    """

    def __init__(self, index: int = CAMERA_INDEX,
                 width: int = CAMERA_WIDTH,
                 height: int = CAMERA_HEIGHT,
                 fps: int = CAMERA_FPS):
        self._index   = index
        self._width   = width
        self._height  = height
        self._fps     = fps
        self._cap: Optional[cv2.VideoCapture] = None
        self._consecutive_failures = 0
        self._MAX_FAILURES = 10

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def open(self, retries: int = 3, delay: float = 1.5):
        """Open camera. Raises CameraError if unavailable after retries."""
        for attempt in range(1, retries + 1):
            cap = cv2.VideoCapture(self._index)

            if not cap.isOpened():
                logger.warning("Camera %d open attempt %d/%d failed.",
                               self._index, attempt, retries)
                cap.release()
                if attempt == retries:
                    raise CameraError(
                        f"Cannot open camera index {self._index}. "
                        "Check that no other application is using it, "
                        "and that the index is correct."
                    )
                time.sleep(delay)
                continue

            # Negotiate resolution & FPS
            cap.set(cv2.CAP_PROP_FRAME_WIDTH,  self._width)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self._height)
            cap.set(cv2.CAP_PROP_FPS,          self._fps)

            actual_w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            actual_h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            actual_f = cap.get(cv2.CAP_PROP_FPS)
            logger.info("Camera %d opened: %d×%d @ %.0ffps",
                        self._index, actual_w, actual_h, actual_f)

            self._cap = cap
            self._consecutive_failures = 0
            return self

        raise CameraError("Failed to open camera.")  # should never reach here

    def close(self):
        if self._cap and self._cap.isOpened():
            self._cap.release()
            self._cap = None
            logger.info("Camera %d closed.", self._index)

    def __enter__(self):
        return self.open()

    def __exit__(self, *_):
        self.close()

    # ── Frame reading ─────────────────────────────────────────────────────────

    def read(self) -> Optional[np.ndarray]:
        """
        Read one frame. Returns BGR ndarray or None on any failure.
        Automatically attempts reconnect after MAX_FAILURES consecutive failures.
        """
        if self._cap is None or not self._cap.isOpened():
            logger.warning("Camera not open — attempting reconnect...")
            try:
                self.open()
            except CameraError as e:
                logger.error("Reconnect failed: %s", e)
                return None

        ret, frame = self._cap.read()

        if not ret or frame is None or frame.size == 0:
            self._consecutive_failures += 1
            logger.warning("Frame read failure #%d", self._consecutive_failures)

            if self._consecutive_failures >= self._MAX_FAILURES:
                logger.error(
                    "Camera %d produced %d consecutive bad frames — reconnecting.",
                    self._index, self._consecutive_failures,
                )
                self.close()
                try:
                    self.open()
                except CameraError:
                    pass
                self._consecutive_failures = 0
            return None

        self._consecutive_failures = 0
        return frame

    def read_stable(self, warmup_frames: int = 5) -> Optional[np.ndarray]:
        """
        Discard a few frames to let auto-exposure / auto-white-balance settle,
        then return the next frame. Use this at the start of each enrollment
        or verification session.
        """
        for _ in range(warmup_frames):
            self._cap.read()
        return self.read()

    # ── Diagnostics ───────────────────────────────────────────────────────────

    def is_open(self) -> bool:
        return self._cap is not None and self._cap.isOpened()

    def resolution(self) -> tuple[int, int]:
        if not self.is_open():
            return (0, 0)
        return (
            int(self._cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
            int(self._cap.get(cv2.CAP_PROP_FRAME_HEIGHT)),
        )

    @staticmethod
    def list_available(max_index: int = 5) -> list[int]:
        """Return list of camera indices that can be opened."""
        available = []
        for idx in range(max_index):
            cap = cv2.VideoCapture(idx)
            if cap.isOpened():
                available.append(idx)
                cap.release()
        return available
