"""
config.py — Central configuration for the Face Recognition System
All tunable parameters in one place.
"""

# ── Database ──────────────────────────────────────────────────────────────────
DB_CONFIG = {
    "host": "localhost",
    "port": 3306,
    "user": "root",
    "password": "your_password_here",   # ← change this
    "database": "face_recognition_db",
    "pool_size": 10,
    "pool_name": "face_pool",
}

# ── ArcFace / InsightFace ─────────────────────────────────────────────────────
ARCFACE_MODEL_NAME   = "buffalo_l"     # buffalo_l = best; buffalo_s = faster
ARCFACE_CTX_ID       = 0              # 0 = first GPU; -1 = CPU only
DETECTION_SIZE       = (640, 640)     # InsightFace detection input size

# ── Verification thresholds ───────────────────────────────────────────────────
COSINE_THRESHOLD     = 0.65           # Minimum cosine similarity to accept
LIVENESS_BLUR_THRESH = 80.0           # Laplacian variance — below = blurry
MIN_FACE_SIZE        = 80             # Minimum face bounding-box side (pixels)
MAX_FACE_SIZE_RATIO  = 0.90           # Face must not fill >90% of frame (too close)
MIN_BRIGHTNESS       = 40             # Mean pixel value — below = too dark
MAX_BRIGHTNESS       = 220            # Above = overexposed

# ── Enrollment ────────────────────────────────────────────────────────────────
ENROLLMENT_FRAMES    = 5              # How many frames to capture for enrollment
ENROLLMENT_INTERVAL  = 0.4           # Seconds between enrollment captures
MIN_GOOD_FRAMES      = 3             # Minimum usable frames to proceed

# ── Camera ────────────────────────────────────────────────────────────────────
CAMERA_INDEX         = 0             # 0 = default webcam
CAMERA_WIDTH         = 1280
CAMERA_HEIGHT        = 720
CAMERA_FPS           = 30

# ── Bilateral filter ──────────────────────────────────────────────────────────
BILATERAL_D          = 9             # Diameter of pixel neighbourhood
BILATERAL_SIGMA_COLOR= 75
BILATERAL_SIGMA_SPACE= 75

# ── Logging ───────────────────────────────────────────────────────────────────
LOG_FILE             = "face_recognition.log"
LOG_LEVEL            = "INFO"        # DEBUG | INFO | WARNING | ERROR

# ── Anti-spoofing (basic) ─────────────────────────────────────────────────────
ENABLE_LIVENESS_CHECK = True         # Set False to skip in trusted environments
BLINK_REQUIRED        = False        # Experimental — requires extra setup
