"""
quality.py — Frame quality checker.

Handles every bad-frame situation before passing to ArcFace:
  - Blur / motion shake
  - Too dark / too bright / overexposed
  - No face detected
  - Multiple faces (ambiguous)
  - Face too small (too far away)
  - Face too large (too close / partial)
  - Face at extreme angle (yaw / pitch / roll)
  - Eyes closed (if InsightFace provides landmarks)
"""

import logging
from dataclasses import dataclass
from enum import Enum, auto
from typing import Optional

import cv2
import numpy as np

from config import (
    LIVENESS_BLUR_THRESH,
    MIN_FACE_SIZE,
    MAX_FACE_SIZE_RATIO,
    MIN_BRIGHTNESS,
    MAX_BRIGHTNESS,
    BILATERAL_D,
    BILATERAL_SIGMA_COLOR,
    BILATERAL_SIGMA_SPACE,
)

logger = logging.getLogger(__name__)


class QualityCode(Enum):
    OK              = auto()
    BLURRY          = auto()
    TOO_DARK        = auto()
    OVEREXPOSED     = auto()
    NO_FACE         = auto()
    MULTIPLE_FACES  = auto()
    FACE_TOO_SMALL  = auto()
    FACE_TOO_CLOSE  = auto()
    BAD_ANGLE       = auto()
    EYES_CLOSED     = auto()
    FRAME_EMPTY     = auto()


@dataclass
class QualityResult:
    code: QualityCode
    message: str
    score: float = 0.0          # blur score / brightness / etc.
    face_count: int = 0
    clean_frame: Optional[np.ndarray] = None   # bilateral-filtered frame

    @property
    def ok(self) -> bool:
        return self.code == QualityCode.OK

    def __str__(self):
        return f"[{self.code.name}] {self.message}"


# ─────────────────────────────────────────────────────────────────────────────
class FrameQualityChecker:
    """
    Run all quality checks on a raw camera frame.
    Call check(frame, faces) after InsightFace detection.
    """

    def check_raw(self, frame: np.ndarray) -> QualityResult:
        """
        Checks that don't require face detection (brightness, blur, empty frame).
        Run this BEFORE InsightFace to save CPU on bad frames.
        """
        if frame is None or frame.size == 0:
            return QualityResult(QualityCode.FRAME_EMPTY, "Empty frame received from camera.")

        # ── Brightness ───────────────────────────────────────────────────────
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        mean_brightness = float(gray.mean())

        if mean_brightness < MIN_BRIGHTNESS:
            return QualityResult(
                QualityCode.TOO_DARK,
                f"Frame too dark (brightness={mean_brightness:.1f}, min={MIN_BRIGHTNESS}). "
                "Turn on a light or use phone screen as fill-light.",
                score=mean_brightness,
            )

        if mean_brightness > MAX_BRIGHTNESS:
            return QualityResult(
                QualityCode.OVEREXPOSED,
                f"Frame overexposed (brightness={mean_brightness:.1f}, max={MAX_BRIGHTNESS}). "
                "Reduce direct light or move away from bright background.",
                score=mean_brightness,
            )

        # ── Blur ─────────────────────────────────────────────────────────────
        blur_score = float(cv2.Laplacian(gray, cv2.CV_64F).var())
        if blur_score < LIVENESS_BLUR_THRESH:
            return QualityResult(
                QualityCode.BLURRY,
                f"Frame too blurry (sharpness={blur_score:.1f}, min={LIVENESS_BLUR_THRESH}). "
                "Hold the camera still.",
                score=blur_score,
            )

        # ── All raw checks passed — apply bilateral filter ────────────────────
        clean = cv2.bilateralFilter(frame, BILATERAL_D,
                                    BILATERAL_SIGMA_COLOR,
                                    BILATERAL_SIGMA_SPACE)
        return QualityResult(
            QualityCode.OK,
            "Raw frame OK.",
            score=blur_score,
            clean_frame=clean,
        )

    def check_faces(self, faces, frame_shape: tuple) -> QualityResult:
        """
        Checks that require InsightFace detection results.
        `faces` is the list returned by app.get(frame).
        `frame_shape` is (H, W, C).
        """
        h, w = frame_shape[:2]

        # ── No face ───────────────────────────────────────────────────────────
        if faces is None or len(faces) == 0:
            return QualityResult(
                QualityCode.NO_FACE,
                "No face detected. Make sure your face is visible and well-lit.",
                face_count=0,
            )

        # ── Multiple faces ────────────────────────────────────────────────────
        if len(faces) > 1:
            return QualityResult(
                QualityCode.MULTIPLE_FACES,
                f"{len(faces)} faces detected. Only one person should be in frame.",
                face_count=len(faces),
            )

        face = faces[0]
        bbox = face.bbox.astype(int)   # [x1, y1, x2, y2]
        fx1, fy1, fx2, fy2 = bbox
        face_w = fx2 - fx1
        face_h = fy2 - fy1

        # ── Face too small ────────────────────────────────────────────────────
        if face_w < MIN_FACE_SIZE or face_h < MIN_FACE_SIZE:
            return QualityResult(
                QualityCode.FACE_TOO_SMALL,
                f"Face too far away (size={face_w}×{face_h}px, min={MIN_FACE_SIZE}px). "
                "Move closer to the camera.",
                face_count=1,
            )

        # ── Face too close ────────────────────────────────────────────────────
        face_area_ratio = (face_w * face_h) / (w * h)
        if face_area_ratio > MAX_FACE_SIZE_RATIO:
            return QualityResult(
                QualityCode.FACE_TOO_CLOSE,
                f"Face too close (fills {face_area_ratio*100:.0f}% of frame). "
                "Move slightly further from the camera.",
                face_count=1,
            )

        # ── Pose / angle check (using InsightFace pose if available) ──────────
        if hasattr(face, "pose") and face.pose is not None:
            yaw, pitch, roll = face.pose
            if abs(yaw) > 30 or abs(pitch) > 30:
                return QualityResult(
                    QualityCode.BAD_ANGLE,
                    f"Face at bad angle (yaw={yaw:.0f}°, pitch={pitch:.0f}°). "
                    "Look directly at the camera.",
                    face_count=1,
                )

        # ── All face checks passed ─────────────────────────────────────────────
        return QualityResult(
            QualityCode.OK,
            "Face quality OK.",
            face_count=1,
        )

    def full_check(self, frame: np.ndarray, faces) -> QualityResult:
        """
        Convenience: run raw checks then face checks.
        Returns the first failure, or QualityCode.OK with clean_frame set.
        """
        raw_result = self.check_raw(frame)
        if not raw_result.ok:
            return raw_result

        face_result = self.check_faces(faces, frame.shape)
        if not face_result.ok:
            return face_result

        # Merge: carry clean_frame from raw result into the final OK result
        return QualityResult(
            QualityCode.OK,
            "All quality checks passed.",
            face_count=face_result.face_count,
            clean_frame=raw_result.clean_frame,
        )
