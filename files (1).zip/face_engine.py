"""
face_engine.py — Core ArcFace wrapper.

Handles:
  - Model loading with retry
  - Enrollment (multi-frame → master vector)
  - 1-to-1 Verification (cosine similarity)
  - All edge cases: model not loaded, no embedding returned, NaN vectors
"""

import logging
import time
from typing import Optional

import numpy as np

from config import (
    ARCFACE_MODEL_NAME,
    ARCFACE_CTX_ID,
    DETECTION_SIZE,
    COSINE_THRESHOLD,
    ENROLLMENT_FRAMES,
    ENROLLMENT_INTERVAL,
    MIN_GOOD_FRAMES,
)
from quality import FrameQualityChecker, QualityCode

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Lazy import InsightFace so the rest of the app still loads if it isn't
# installed (useful for running unit tests without GPU).
# ─────────────────────────────────────────────────────────────────────────────
def _load_insightface():
    try:
        import insightface
        from insightface.app import FaceAnalysis
        return FaceAnalysis
    except ImportError as e:
        raise RuntimeError(
            "InsightFace not installed. Run: pip install insightface onnxruntime"
        ) from e


# ─────────────────────────────────────────────────────────────────────────────
class VerificationResult:
    def __init__(self, passed: bool, score: float, message: str,
                 name: str = "", fail_reason: str = ""):
        self.passed      = passed
        self.score       = score
        self.message     = message
        self.name        = name          # full name of matched user
        self.fail_reason = fail_reason

    def __str__(self):
        status = "PASS" if self.passed else "FAIL"
        return f"[{status}] score={self.score:.4f} | {self.message}"


# ─────────────────────────────────────────────────────────────────────────────
class FaceEngine:
    """
    Singleton-style wrapper around InsightFace ArcFace model.
    Thread-safe for read (verification); enrollment locks via threading in main.
    """

    def __init__(self):
        self._app = None
        self._checker = FrameQualityChecker()
        self._load_model()

    # ── Model loading ─────────────────────────────────────────────────────────

    def _load_model(self, retries: int = 3):
        FaceAnalysis = _load_insightface()
        for attempt in range(1, retries + 1):
            try:
                app = FaceAnalysis(name=ARCFACE_MODEL_NAME,
                                   providers=["CUDAExecutionProvider",
                                              "CPUExecutionProvider"])
                app.prepare(ctx_id=ARCFACE_CTX_ID, det_size=DETECTION_SIZE)
                self._app = app
                logger.info("ArcFace model '%s' loaded (ctx_id=%d).",
                            ARCFACE_MODEL_NAME, ARCFACE_CTX_ID)
                return
            except Exception as e:
                logger.warning("Model load attempt %d/%d failed: %s", attempt, retries, e)
                if attempt == retries:
                    raise RuntimeError(f"Cannot load ArcFace model: {e}") from e
                time.sleep(2)

    def _ensure_model(self):
        if self._app is None:
            raise RuntimeError("ArcFace model is not loaded.")

    # ── Embedding extraction ──────────────────────────────────────────────────

    def extract_embedding(self, frame: np.ndarray) -> Optional[np.ndarray]:
        """
        Given a BGR frame, run raw quality check, detect faces, run face quality
        check, then return the 512-dim L2-normalised embedding.
        Returns None on any failure (caller should check quality logs).
        """
        self._ensure_model()

        # Raw quality (blur, brightness) before detection
        raw_result = self._checker.check_raw(frame)
        if not raw_result.ok:
            logger.debug("Raw quality fail: %s", raw_result)
            return None

        # Run InsightFace on the clean (bilateral-filtered) frame
        clean_frame = raw_result.clean_frame
        try:
            faces = self._app.get(clean_frame)
        except Exception as e:
            logger.error("InsightFace detection error: %s", e)
            return None

        # Face quality check
        face_result = self._checker.check_faces(faces, frame.shape)
        if not face_result.ok:
            logger.debug("Face quality fail: %s", face_result)
            return None

        face = faces[0]

        # Guard: ArcFace may return None embedding on very unusual frames
        if face.normed_embedding is None:
            logger.warning("ArcFace returned None embedding — skipping frame.")
            return None

        embedding = np.array(face.normed_embedding, dtype=np.float32)

        # Guard: NaN / Inf in embedding (corrupted model output)
        if not np.isfinite(embedding).all():
            logger.warning("Non-finite values in embedding — skipping frame.")
            return None

        # L2-normalise (InsightFace already does this for normed_embedding,
        # but we re-normalise defensively)
        norm = np.linalg.norm(embedding)
        if norm < 1e-6:
            logger.warning("Near-zero norm embedding — skipping frame.")
            return None

        return embedding / norm

    def extract_embedding_with_quality(self, frame: np.ndarray):
        """
        Returns (embedding_or_None, quality_result) for caller to surface
        the exact failure reason to the user / UI.
        """
        self._ensure_model()

        raw_result = self._checker.check_raw(frame)
        if not raw_result.ok:
            return None, raw_result

        clean_frame = raw_result.clean_frame
        try:
            faces = self._app.get(clean_frame)
        except Exception as e:
            from quality import QualityResult
            return None, QualityResult(QualityCode.NO_FACE,
                                       f"Detection error: {e}")

        face_result = self._checker.check_faces(faces, frame.shape)
        if not face_result.ok:
            return None, face_result

        face = faces[0]
        if face.normed_embedding is None:
            from quality import QualityResult
            return None, QualityResult(QualityCode.NO_FACE,
                                       "ArcFace returned no embedding.")

        embedding = np.array(face.normed_embedding, dtype=np.float32)
        if not np.isfinite(embedding).all():
            from quality import QualityResult
            return None, QualityResult(QualityCode.NO_FACE,
                                       "Embedding contains invalid values.")

        norm = np.linalg.norm(embedding)
        if norm < 1e-6:
            from quality import QualityResult
            return None, QualityResult(QualityCode.NO_FACE,
                                       "Embedding norm too small.")

        embedding = embedding / norm
        return embedding, raw_result   # raw_result.ok = True here

    # ── Enrollment ────────────────────────────────────────────────────────────

    def build_master_vector(self, frames: list[np.ndarray]) -> Optional[np.ndarray]:
        """
        Given a list of BGR frames, extract embeddings from each, discard bad
        ones, and return the averaged + re-normalised master vector.
        Returns None if fewer than MIN_GOOD_FRAMES usable frames.
        """
        embeddings = []
        for i, frame in enumerate(frames):
            emb = self.extract_embedding(frame)
            if emb is not None:
                embeddings.append(emb)
                logger.debug("Frame %d/%d — embedding OK", i + 1, len(frames))
            else:
                logger.debug("Frame %d/%d — embedding skipped", i + 1, len(frames))

        good = len(embeddings)
        logger.info("Good frames: %d / %d (need %d)", good, len(frames), MIN_GOOD_FRAMES)

        if good < MIN_GOOD_FRAMES:
            return None

        master = np.mean(embeddings, axis=0)
        norm   = np.linalg.norm(master)
        if norm < 1e-6:
            logger.error("Master vector has near-zero norm — enrollment failed.")
            return None

        return master / norm

    # ── Verification ─────────────────────────────────────────────────────────

    def verify(self, live_frame: np.ndarray,
               stored_name: str,
               stored_vector: np.ndarray) -> VerificationResult:
        """
        1-to-1 cosine similarity check.
        `stored_vector` comes directly from the DB (already L2-normalised).
        """
        live_emb, quality = self.extract_embedding_with_quality(live_frame)

        if live_emb is None:
            return VerificationResult(
                passed=False,
                score=0.0,
                message=str(quality),
                fail_reason=quality.code.name,
            )

        # Cosine similarity (both vectors are L2-normalised → dot product = cosine)
        score = float(np.dot(live_emb, stored_vector))
        # Clamp to [-1, 1] to handle floating-point edge cases
        score = max(-1.0, min(1.0, score))

        passed = score >= COSINE_THRESHOLD

        if passed:
            return VerificationResult(
                passed=True,
                score=score,
                message=f"Identity confirmed: {stored_name} (score={score:.4f})",
                name=stored_name,
            )
        else:
            return VerificationResult(
                passed=False,
                score=score,
                message=f"Identity NOT confirmed (score={score:.4f}, threshold={COSINE_THRESHOLD})",
                fail_reason="LOW_SCORE",
            )

    # ── Utility ───────────────────────────────────────────────────────────────

    @staticmethod
    def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
        """Pure cosine similarity between two vectors (handles non-normalised)."""
        a_norm = np.linalg.norm(a)
        b_norm = np.linalg.norm(b)
        if a_norm < 1e-6 or b_norm < 1e-6:
            return 0.0
        return float(np.dot(a / a_norm, b / b_norm))
