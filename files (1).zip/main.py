"""
main.py — Entry point for the Face Recognition System.

Features:
  - Interactive CLI menu
  - Enrollment (multi-frame, master vector, DB store)
  - Real-time live verification loop (with on-screen HUD)
  - Concurrent enrollment + verification via threading
  - Graceful shutdown on Ctrl+C or 'q'
  - All exceptions caught and surfaced clearly

Usage:
    python main.py

Dependencies:
    pip install insightface onnxruntime opencv-python mysql-connector-python numpy
"""

import logging
import sys
import threading
import time
from typing import Optional

import cv2
import numpy as np

# ── Local modules ─────────────────────────────────────────────────────────────
from config import (
    LOG_FILE, LOG_LEVEL,
    ENROLLMENT_FRAMES, ENROLLMENT_INTERVAL, MIN_GOOD_FRAMES,
)
from camera     import Camera, CameraError
from database   import DatabaseManager
from face_engine import FaceEngine, VerificationResult
from quality    import QualityCode


# ─────────────────────────────────────────────────────────────────────────────
# Logging setup
# ─────────────────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL, logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("main")


# ─────────────────────────────────────────────────────────────────────────────
# HUD helpers (drawn on OpenCV frame)
# ─────────────────────────────────────────────────────────────────────────────
COLOR_OK    = (50, 205, 50)    # green
COLOR_FAIL  = (50, 50, 220)    # red (BGR)
COLOR_WARN  = (0, 165, 255)    # orange
COLOR_WHITE = (255, 255, 255)
FONT        = cv2.FONT_HERSHEY_SIMPLEX


def draw_hud(frame: np.ndarray, lines: list[tuple[str, tuple]]) -> np.ndarray:
    """Draw text lines on frame. Each item: (text, color)."""
    y = 30
    for text, color in lines:
        cv2.putText(frame, text, (10, y), FONT, 0.65, (0, 0, 0), 4, cv2.LINE_AA)
        cv2.putText(frame, text, (10, y), FONT, 0.65, color,   2, cv2.LINE_AA)
        y += 28
    return frame


def draw_face_box(frame: np.ndarray, bbox, color=(0, 255, 0)) -> np.ndarray:
    x1, y1, x2, y2 = [int(v) for v in bbox]
    cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
    return frame


# ─────────────────────────────────────────────────────────────────────────────
# Enrollment worker
# ─────────────────────────────────────────────────────────────────────────────
def enroll_user(db: DatabaseManager, engine: FaceEngine,
                lock: threading.Lock):
    """Interactive enrollment. Can run in its own thread."""
    print("\n── ENROLL NEW USER ──────────────────────────────")
    serial = input("  Serial Number : ").strip()
    if not serial:
        print("  [!] Serial number cannot be empty.")
        return

    name = input("  Full Name     : ").strip()
    if not name:
        print("  [!] Name cannot be empty.")
        return

    notes = input("  Notes (opt.)  : ").strip()

    # Check if already enrolled
    existing = db.get_user_vector(serial)
    if existing:
        overwrite = input(f"  [!] '{serial}' already enrolled. Overwrite? [y/N]: ").strip().lower()
        if overwrite != "y":
            print("  Enrollment cancelled.")
            return

    print(f"\n  Opening camera — capturing {ENROLLMENT_FRAMES} frames for '{name}'...")
    print("  TIP: Look directly at the camera. Hold still.")

    try:
        cam = Camera()
        cam.open()
    except CameraError as e:
        print(f"  [ERROR] {e}")
        return

    frames_collected = []

    # Warm up camera
    cam.read_stable(warmup_frames=5)

    for i in range(ENROLLMENT_FRAMES):
        frame = cam.read()
        if frame is None:
            print(f"  [WARN] Frame {i+1} could not be read — skipping.")
            time.sleep(ENROLLMENT_INTERVAL)
            continue

        # Show preview window with countdown
        preview = frame.copy()
        draw_hud(preview, [
            (f"Enrolling: {name}", COLOR_OK),
            (f"Frame {i+1}/{ENROLLMENT_FRAMES} — hold still", COLOR_WHITE),
        ])
        cv2.imshow("Enrollment", preview)
        cv2.waitKey(1)

        frames_collected.append(frame)
        print(f"  Frame {i+1}/{ENROLLMENT_FRAMES} captured.")
        time.sleep(ENROLLMENT_INTERVAL)

    cam.close()
    cv2.destroyWindow("Enrollment")

    if len(frames_collected) < MIN_GOOD_FRAMES:
        print(f"  [ERROR] Only {len(frames_collected)} frames captured. Need {MIN_GOOD_FRAMES}.")
        return

    print("  Processing embeddings...")
    with lock:   # prevent concurrent DB writes during enrollment
        master_vector = engine.build_master_vector(frames_collected)

    if master_vector is None:
        print(f"  [ERROR] Could not build master vector from frames.")
        print("  Possible causes: blurry frames, bad lighting, no face detected.")
        print(f"  Try again with better lighting or move closer to the camera.")
        return

    success = db.enroll_user(serial, name, master_vector, notes)
    if success:
        print(f"\n  ✓ '{name}' enrolled successfully as [{serial}]")
    else:
        print(f"  [ERROR] Database write failed — check logs.")


# ─────────────────────────────────────────────────────────────────────────────
# Verification loop
# ─────────────────────────────────────────────────────────────────────────────
def verify_loop(db: DatabaseManager, engine: FaceEngine,
                lock: threading.Lock):
    """
    Live verification loop.
    Opens camera, shows live feed, and verifies on demand.
    Press SPACE to verify, Q to quit.
    """
    print("\n── LIVE VERIFICATION ────────────────────────────")
    serial = input("  Enter Serial Number to verify: ").strip()
    if not serial:
        print("  [!] Serial number cannot be empty.")
        return

    # Fetch stored vector once (1-to-1: single DB lookup)
    with lock:
        user_data = db.get_user_vector(serial)

    if user_data is None:
        print(f"  [!] Serial '{serial}' not found or inactive in database.")
        return

    stored_name, stored_vector = user_data
    print(f"  Loaded profile: {stored_name}")
    print("  Camera live — press SPACE to verify, Q to quit.\n")

    try:
        cam = Camera()
        cam.open()
    except CameraError as e:
        print(f"  [ERROR] {e}")
        return

    last_result: Optional[VerificationResult] = None
    result_timestamp = 0.0
    RESULT_DISPLAY_SECONDS = 4.0

    try:
        while True:
            frame = cam.read()
            if frame is None:
                # Camera hiccup — show warning, keep trying
                blank = np.zeros((480, 640, 3), dtype=np.uint8)
                draw_hud(blank, [("Camera error — reconnecting...", COLOR_WARN)])
                cv2.imshow("Verification", blank)
                if cv2.waitKey(100) & 0xFF in (ord("q"), 27):
                    break
                continue

            display = frame.copy()

            # ── Draw persistent result for N seconds ─────────────────────────
            elapsed = time.time() - result_timestamp
            if last_result and elapsed < RESULT_DISPLAY_SECONDS:
                if last_result.passed:
                    draw_hud(display, [
                        (f"VERIFIED: {last_result.name}", COLOR_OK),
                        (f"Score: {last_result.score:.4f}", COLOR_OK),
                    ])
                else:
                    draw_hud(display, [
                        ("ACCESS DENIED", COLOR_FAIL),
                        (f"Score: {last_result.score:.4f} | {last_result.fail_reason}", COLOR_FAIL),
                    ])
            else:
                draw_hud(display, [
                    (f"User: {stored_name} [{serial}]", COLOR_WHITE),
                    ("SPACE = verify  |  Q = quit", COLOR_WHITE),
                ])

            cv2.imshow("Verification", display)
            key = cv2.waitKey(1) & 0xFF

            if key in (ord("q"), 27):
                break

            if key == ord(" "):
                # ── Verify now ────────────────────────────────────────────────
                print("  Verifying...", end=" ", flush=True)
                result = engine.verify(frame, stored_name, stored_vector)

                if result.passed:
                    print(f"PASS — score={result.score:.4f}")
                    db.update_last_seen(serial)
                    db.reset_failed_attempts(serial)
                    db.log_verification(serial, result.score, "PASS")
                else:
                    print(f"FAIL — score={result.score:.4f} | {result.fail_reason}")
                    db.increment_failed_attempts(serial)
                    db.log_verification(serial, result.score, "FAIL", result.fail_reason)

                last_result = result
                result_timestamp = time.time()

    finally:
        cam.close()
        cv2.destroyWindow("Verification")


# ─────────────────────────────────────────────────────────────────────────────
# Auto continuous verification (for kiosk / door-lock use)
# ─────────────────────────────────────────────────────────────────────────────
def auto_verify_loop(db: DatabaseManager, engine: FaceEngine,
                     lock: threading.Lock):
    """
    Continuous: ask for serial number each time, keep verifying automatically
    every N seconds without pressing SPACE.  Good for turnstile / door lock.
    """
    print("\n── AUTO CONTINUOUS VERIFY ───────────────────────")
    serial = input("  Serial Number: ").strip()
    if not serial:
        return

    with lock:
        user_data = db.get_user_vector(serial)
    if user_data is None:
        print(f"  [!] '{serial}' not found.")
        return

    stored_name, stored_vector = user_data
    VERIFY_EVERY = 2.0   # seconds between auto-checks

    try:
        cam = Camera()
        cam.open()
    except CameraError as e:
        print(f"  [ERROR] {e}")
        return

    last_check = 0.0
    last_result = None
    result_ts   = 0.0

    print(f"  Auto-verifying '{stored_name}' every {VERIFY_EVERY:.0f}s. Press Q to stop.")

    try:
        while True:
            frame = cam.read()
            if frame is None:
                time.sleep(0.05)
                continue

            now = time.time()
            display = frame.copy()

            if now - last_check >= VERIFY_EVERY:
                last_check = now
                result = engine.verify(frame, stored_name, stored_vector)
                last_result = result
                result_ts = now

                if result.passed:
                    db.update_last_seen(serial)
                    db.reset_failed_attempts(serial)
                    db.log_verification(serial, result.score, "PASS")
                    print(f"  AUTO PASS — {result.score:.4f}")
                else:
                    db.increment_failed_attempts(serial)
                    db.log_verification(serial, result.score, "FAIL", result.fail_reason)
                    print(f"  AUTO FAIL — {result.score:.4f} | {result.fail_reason}")

            # HUD
            if last_result and (now - result_ts < 2.0):
                color = COLOR_OK if last_result.passed else COLOR_FAIL
                label = "PASS" if last_result.passed else "FAIL"
                draw_hud(display, [
                    (f"{label}: {last_result.score:.4f}", color),
                    (f"User: {stored_name}", COLOR_WHITE),
                ])
            else:
                draw_hud(display, [
                    (f"Monitoring: {stored_name}", COLOR_WHITE),
                    ("Q = quit", COLOR_WHITE),
                ])

            cv2.imshow("Auto Verify", display)
            if cv2.waitKey(1) & 0xFF in (ord("q"), 27):
                break

    finally:
        cam.close()
        cv2.destroyWindow("Auto Verify")


# ─────────────────────────────────────────────────────────────────────────────
# Admin utilities
# ─────────────────────────────────────────────────────────────────────────────
def list_users(db: DatabaseManager):
    users = db.list_users()
    if not users:
        print("  No enrolled users.")
        return
    print(f"\n  {'Serial':<20} {'Name':<25} {'Enrolled':<22} {'Last Seen':<22} {'Fails'}")
    print("  " + "─" * 95)
    for u in users:
        print(f"  {u['serial_number']:<20} {u['full_name']:<25} "
              f"{str(u['enrolled_at']):<22} {str(u['last_seen'] or 'Never'):<22} "
              f"{u['failed_attempts']}")


def delete_user(db: DatabaseManager):
    serial = input("  Serial Number to deactivate: ").strip()
    if not serial:
        return
    confirm = input(f"  Deactivate '{serial}'? [y/N]: ").strip().lower()
    if confirm == "y":
        ok = db.delete_user(serial)
        print(f"  {'Done.' if ok else 'Not found.'}")


# ─────────────────────────────────────────────────────────────────────────────
# Main menu
# ─────────────────────────────────────────────────────────────────────────────
def main():
    print("=" * 55)
    print("  Face Recognition System — ArcFace + MySQL")
    print("=" * 55)

    # ── Initialise subsystems ─────────────────────────────────────────────────
    print("\n  Starting up...")

    try:
        db = DatabaseManager()
        print("  ✓ Database connected.")
    except RuntimeError as e:
        print(f"  [FATAL] Database: {e}")
        sys.exit(1)

    try:
        engine = FaceEngine()
        print("  ✓ ArcFace model loaded.")
    except RuntimeError as e:
        print(f"  [FATAL] ArcFace: {e}")
        sys.exit(1)

    lock = threading.Lock()   # Shared lock for DB writes during concurrent ops

    # ── Menu loop ─────────────────────────────────────────────────────────────
    MENU = """
  ┌─────────────────────────────────────────┐
  │  1 — Enroll new user                    │
  │  2 — Verify (manual SPACE trigger)      │
  │  3 — Verify (auto-continuous)           │
  │  4 — Enroll + Verify simultaneously     │
  │  5 — List enrolled users                │
  │  6 — Deactivate user                    │
  │  Q — Quit                               │
  └─────────────────────────────────────────┘
"""

    while True:
        print(MENU)
        choice = input("  Choice: ").strip().lower()

        if choice == "1":
            enroll_user(db, engine, lock)

        elif choice == "2":
            verify_loop(db, engine, lock)

        elif choice == "3":
            auto_verify_loop(db, engine, lock)

        elif choice == "4":
            # Run enrollment and verification concurrently in separate threads
            t_enroll = threading.Thread(
                target=enroll_user, args=(db, engine, lock),
                daemon=True, name="EnrollThread"
            )
            t_verify = threading.Thread(
                target=verify_loop, args=(db, engine, lock),
                daemon=True, name="VerifyThread"
            )
            print("  Starting enrollment and verification threads simultaneously...")
            t_enroll.start()
            t_verify.start()
            t_enroll.join()
            t_verify.join()
            print("  Both operations complete.")

        elif choice == "5":
            list_users(db)

        elif choice == "6":
            delete_user(db)

        elif choice in ("q", "quit", "exit"):
            print("\n  Goodbye.\n")
            cv2.destroyAllWindows()
            sys.exit(0)

        else:
            print("  [!] Invalid choice.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n  [Ctrl+C] Shutting down.")
        cv2.destroyAllWindows()
        sys.exit(0)
