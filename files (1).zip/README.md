# Face Recognition System
## ArcFace (InsightFace) + MySQL + OpenCV — Production Ready

---

## Project Structure

```
face_recognition_system/
├── config.py        ← All tunable settings (thresholds, DB, camera)
├── database.py      ← MySQL manager (connection pool, CRUD, logging)
├── quality.py       ← Frame quality checks (blur, brightness, pose...)
├── face_engine.py   ← ArcFace wrapper (enrollment, verification)
├── camera.py        ← Camera manager (auto-reconnect, read failures)
├── main.py          ← CLI entry point + concurrent threading
├── requirements.txt
└── README.md
```

---

## Setup

### 1. Install Python dependencies
```bash
pip install -r requirements.txt
```

> **No GPU?** Replace `onnxruntime-gpu` with `onnxruntime` in requirements.txt  
> and set `ARCFACE_CTX_ID = -1` in config.py

### 2. Install MySQL
```bash
# Ubuntu/Debian
sudo apt install mysql-server
sudo systemctl start mysql

# macOS (Homebrew)
brew install mysql
brew services start mysql
```

### 3. Configure database credentials
Edit `config.py`:
```python
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "your_password_here",   # ← set this
    ...
}
```

The database and tables are created **automatically** on first run.

### 4. Run
```bash
python main.py
```

---

## Usage

### Menu options
| Option | Description |
|--------|-------------|
| 1 | Enroll a new user (captures 5 frames, builds master vector) |
| 2 | Verify a user — press SPACE to check, Q to quit |
| 3 | Auto-verify every 2 seconds (kiosk / door-lock mode) |
| 4 | Run enrollment + verification **simultaneously** (threading) |
| 5 | List all enrolled users |
| 6 | Deactivate a user (soft delete) |

---

## All Situations Handled

| Situation | Handled in |
|-----------|-----------|
| Camera not found | `camera.py` — CameraError with clear message |
| Camera disconnects mid-session | `camera.py` — auto-reconnect |
| Bad frame / read failure | `camera.py` — returns None, retries |
| Frame too dark | `quality.py` — QualityCode.TOO_DARK |
| Frame overexposed | `quality.py` — QualityCode.OVEREXPOSED |
| Blurry / shaky frame | `quality.py` — QualityCode.BLURRY (Laplacian) |
| No face in frame | `quality.py` — QualityCode.NO_FACE |
| Multiple faces | `quality.py` — QualityCode.MULTIPLE_FACES |
| Face too far away | `quality.py` — QualityCode.FACE_TOO_SMALL |
| Face too close (partial) | `quality.py` — QualityCode.FACE_TOO_CLOSE |
| Extreme head angle | `quality.py` — QualityCode.BAD_ANGLE |
| ArcFace returns None | `face_engine.py` — guarded, skips frame |
| NaN/Inf in embedding | `face_engine.py` — guarded, skips frame |
| Not enough good frames | `face_engine.py` — enrollment fails cleanly |
| Serial number not found | `database.py` — returns None |
| DB connection pool exhausted | `database.py` — RuntimeError with message |
| MySQL down at startup | `database.py` — retry 5× then fatal |
| Concurrent enroll + verify | `main.py` — threading.Lock on DB writes |
| User already enrolled | `main.py` — asks to overwrite |
| Wrong serial number | `main.py` — user not found message |
| Low cosine score | `face_engine.py` — FAIL with score shown |
| Model not installed | `face_engine.py` — RuntimeError + pip hint |

---

## Tuning

All thresholds are in `config.py`:

```python
COSINE_THRESHOLD     = 0.65   # ↑ stricter, ↓ more lenient
LIVENESS_BLUR_THRESH = 80.0   # ↑ reject more blur
MIN_FACE_SIZE        = 80     # ↑ require closer face
ENROLLMENT_FRAMES    = 5      # ↑ more frames = better accuracy
MIN_GOOD_FRAMES      = 3      # minimum usable enrollment frames
```

---

## Scaling to 25,000+ Users

This system uses **1-to-1 verification** (not 1-to-N search):
- MySQL fetches **one row** by primary key (serial number)
- One cosine dot product — `O(1)` regardless of database size
- Works identically at 100 users or 100,000 users

For 1-to-N search (identify unknown person from database):  
Use FAISS or Milvus vector index alongside this system.
