"""
database.py — MySQL database manager with connection pooling.

Handles:
  - Schema creation on first run
  - Storing / retrieving 512-dim face vectors as BLOBs
  - Updating / deleting users
  - Thread-safe connection pooling
  - Full error handling & retry logic
"""

import logging
import pickle
import time
from contextlib import contextmanager
from typing import Optional

import mysql.connector
from mysql.connector import pooling, errors as mysql_errors
import numpy as np

from config import DB_CONFIG

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Schema SQL
# ─────────────────────────────────────────────────────────────────────────────
CREATE_DB_SQL = f"CREATE DATABASE IF NOT EXISTS {DB_CONFIG['database']} CHARACTER SET utf8mb4;"

CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS users (
    serial_number   VARCHAR(64)  PRIMARY KEY,
    full_name       VARCHAR(128) NOT NULL,
    master_vector   LONGBLOB     NOT NULL,
    enrolled_at     DATETIME     DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active       TINYINT(1)   DEFAULT 1,
    failed_attempts INT          DEFAULT 0,
    last_seen       DATETIME     NULL,
    notes           TEXT         NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
"""

CREATE_LOG_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS verification_log (
    id              BIGINT       AUTO_INCREMENT PRIMARY KEY,
    serial_number   VARCHAR(64)  NOT NULL,
    verified_at     DATETIME     DEFAULT CURRENT_TIMESTAMP,
    cosine_score    FLOAT        NOT NULL,
    result          ENUM('PASS','FAIL','ERROR') NOT NULL,
    fail_reason     VARCHAR(128) NULL,
    INDEX idx_serial (serial_number),
    INDEX idx_time   (verified_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
"""


# ─────────────────────────────────────────────────────────────────────────────
# DatabaseManager
# ─────────────────────────────────────────────────────────────────────────────
class DatabaseManager:
    """Thread-safe MySQL manager with connection pooling."""

    _pool: Optional[pooling.MySQLConnectionPool] = None

    def __init__(self):
        self._init_pool()
        self._ensure_schema()

    # ── Pool ─────────────────────────────────────────────────────────────────

    def _init_pool(self, retries: int = 5, delay: float = 2.0):
        """Create the connection pool, retrying if MySQL isn't ready yet."""
        cfg = {k: v for k, v in DB_CONFIG.items()
               if k not in ("database", "pool_size", "pool_name")}

        for attempt in range(1, retries + 1):
            try:
                # Connect without specifying database first (it may not exist yet)
                temp = mysql.connector.connect(**cfg)
                cursor = temp.cursor()
                cursor.execute(CREATE_DB_SQL)
                cursor.close()
                temp.close()

                # Now create the real pool
                pool_cfg = {**DB_CONFIG}
                self._pool = pooling.MySQLConnectionPool(
                    pool_name=pool_cfg.pop("pool_name"),
                    pool_size=pool_cfg.pop("pool_size"),
                    **pool_cfg,
                )
                logger.info("MySQL connection pool created (size=%d)", DB_CONFIG["pool_size"])
                return

            except mysql_errors.Error as e:
                logger.warning("DB connect attempt %d/%d failed: %s", attempt, retries, e)
                if attempt == retries:
                    raise RuntimeError(f"Cannot connect to MySQL after {retries} attempts: {e}") from e
                time.sleep(delay)

    @contextmanager
    def _get_connection(self):
        """Borrow a connection from the pool; always release it."""
        conn = None
        try:
            conn = self._pool.get_connection()
            yield conn
        except mysql_errors.PoolExhausted:
            logger.error("Connection pool exhausted — all %d connections in use", DB_CONFIG["pool_size"])
            raise RuntimeError("Database pool exhausted. Too many concurrent requests.")
        except mysql_errors.Error as e:
            logger.error("MySQL error: %s", e)
            raise
        finally:
            if conn and conn.is_connected():
                conn.close()   # returns to pool

    # ── Schema ───────────────────────────────────────────────────────────────

    def _ensure_schema(self):
        with self._get_connection() as conn:
            cur = conn.cursor()
            cur.execute(CREATE_TABLE_SQL)
            cur.execute(CREATE_LOG_TABLE_SQL)
            conn.commit()
            cur.close()
        logger.info("Database schema verified.")

    # ── User CRUD ─────────────────────────────────────────────────────────────

    def enroll_user(self, serial_number: str, full_name: str,
                    master_vector: np.ndarray, notes: str = "") -> bool:
        """
        Insert a new user or REPLACE their vector if serial_number already exists.
        Returns True on success.
        """
        blob = self._vector_to_blob(master_vector)
        sql = """
            INSERT INTO users (serial_number, full_name, master_vector, notes)
            VALUES (%s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                full_name     = VALUES(full_name),
                master_vector = VALUES(master_vector),
                notes         = VALUES(notes),
                updated_at    = CURRENT_TIMESTAMP
        """
        try:
            with self._get_connection() as conn:
                cur = conn.cursor()
                cur.execute(sql, (serial_number, full_name, blob, notes))
                conn.commit()
                cur.close()
            logger.info("Enrolled user: %s (%s)", serial_number, full_name)
            return True

        except mysql_errors.Error as e:
            logger.error("Enroll failed for %s: %s", serial_number, e)
            return False

    def get_user_vector(self, serial_number: str) -> Optional[tuple]:
        """
        Fetch (full_name, master_vector_ndarray) for the given serial_number.
        Returns None if not found or user is inactive.
        """
        sql = """
            SELECT full_name, master_vector
            FROM users
            WHERE serial_number = %s AND is_active = 1
        """
        try:
            with self._get_connection() as conn:
                cur = conn.cursor()
                cur.execute(sql, (serial_number,))
                row = cur.fetchone()
                cur.close()

            if row is None:
                logger.warning("Serial number not found or inactive: %s", serial_number)
                return None

            full_name, blob = row
            return full_name, self._blob_to_vector(blob)

        except mysql_errors.Error as e:
            logger.error("get_user_vector failed for %s: %s", serial_number, e)
            return None

    def update_last_seen(self, serial_number: str):
        sql = "UPDATE users SET last_seen = NOW() WHERE serial_number = %s"
        with self._get_connection() as conn:
            cur = conn.cursor()
            cur.execute(sql, (serial_number,))
            conn.commit()
            cur.close()

    def increment_failed_attempts(self, serial_number: str):
        sql = "UPDATE users SET failed_attempts = failed_attempts + 1 WHERE serial_number = %s"
        with self._get_connection() as conn:
            cur = conn.cursor()
            cur.execute(sql, (serial_number,))
            conn.commit()
            cur.close()

    def reset_failed_attempts(self, serial_number: str):
        sql = "UPDATE users SET failed_attempts = 0 WHERE serial_number = %s"
        with self._get_connection() as conn:
            cur = conn.cursor()
            cur.execute(sql, (serial_number,))
            conn.commit()
            cur.close()

    def delete_user(self, serial_number: str) -> bool:
        """Soft-delete by setting is_active = 0."""
        sql = "UPDATE users SET is_active = 0 WHERE serial_number = %s"
        try:
            with self._get_connection() as conn:
                cur = conn.cursor()
                cur.execute(sql, (serial_number,))
                affected = cur.rowcount
                conn.commit()
                cur.close()
            return affected > 0
        except mysql_errors.Error as e:
            logger.error("delete_user failed for %s: %s", serial_number, e)
            return False

    def list_users(self) -> list[dict]:
        """Return all active users (without vectors)."""
        sql = """
            SELECT serial_number, full_name, enrolled_at, last_seen, failed_attempts
            FROM users WHERE is_active = 1 ORDER BY enrolled_at DESC
        """
        with self._get_connection() as conn:
            cur = conn.cursor(dictionary=True)
            cur.execute(sql)
            rows = cur.fetchall()
            cur.close()
        return rows

    # ── Verification log ──────────────────────────────────────────────────────

    def log_verification(self, serial_number: str, score: float,
                         result: str, fail_reason: str = ""):
        sql = """
            INSERT INTO verification_log
                (serial_number, cosine_score, result, fail_reason)
            VALUES (%s, %s, %s, %s)
        """
        try:
            with self._get_connection() as conn:
                cur = conn.cursor()
                cur.execute(sql, (serial_number, float(score), result, fail_reason))
                conn.commit()
                cur.close()
        except mysql_errors.Error as e:
            logger.warning("Could not write verification log: %s", e)

    # ── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _vector_to_blob(vec: np.ndarray) -> bytes:
        return pickle.dumps(vec.astype(np.float32))

    @staticmethod
    def _blob_to_vector(blob: bytes) -> np.ndarray:
        return pickle.loads(blob).astype(np.float32)
